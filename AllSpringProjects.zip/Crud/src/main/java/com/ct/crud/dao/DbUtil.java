package com.ct.crud.dao;

public class DbUtil {

}
