package com.ct.crud.model;

public class Product {

	private int prodId;
	private String prodName;
	private String prodDes;
	private String prodPrice;
	public int getProdId() {
		return prodId;
	}
	public void setProdId(int prodId) {
		this.prodId = prodId;
	}
	public String getProdName() {
		return prodName;
	}
	public void setProdName(String prodName) {
		this.prodName = prodName;
	}
	public String getProdDes() {
		return prodDes;
	}
	public void setProdDes(String prodDes) {
		this.prodDes = prodDes;
	}
	public String getProdPrice() {
		return prodPrice;
	}
	public void setProdPrice(String prodPrice) {
		this.prodPrice = prodPrice;
	}
	@Override
	public String toString() {
		return "Product [prodId=" + prodId + ", prodName=" + prodName + ", prodDes=" + prodDes + ", prodPrice="
				+ prodPrice + "]";
	}
	public Product() {
	}
	
	
	
}
