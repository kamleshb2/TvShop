package com.ct.crud.service;

import com.ct.crud.model.Product;

public interface IService {

	
	public boolean addProduct(Product p);
	public boolean deleteProduct(int id);
	public boolean updateProduct();
}
