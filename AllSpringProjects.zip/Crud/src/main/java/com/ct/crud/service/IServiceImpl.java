package com.ct.crud.service;

import com.ct.crud.model.Product;

public class IServiceImpl implements IService {

	public boolean addProduct(Product p) {
	
		return false;
	}

	public boolean deleteProduct(int id) {
		
		return false;
	}

	public boolean updateProduct() {
		
		return false;
	}

	
}
