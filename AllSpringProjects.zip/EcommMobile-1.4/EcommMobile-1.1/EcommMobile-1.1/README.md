# EcommMobile
Training project to check and update mobile information
