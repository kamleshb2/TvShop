package com.ct.view;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Servlet2
 */
@WebServlet("/s2")
public class Servlet2 extends HttpServlet {
	PrintWriter out=null;
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//generate link to serv 3
		resp.setContentType("text/html");
	//	String finalData=req.getParameter("id")+" "+req.getParameter("name")+" "+req.getParameter("price");
		out=resp.getWriter();
		//out.println(finalData);
		HttpSession ses=req.getSession();
		out.println(ses.getAttribute("id"));
		out.println(ses.getAttribute("name"));
		out.println(ses.getAttribute("price"));
		out.println("<a href='s3'>click for serv 3</a>");
		
	}
}