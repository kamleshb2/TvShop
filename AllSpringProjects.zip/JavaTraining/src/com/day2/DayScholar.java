package com.day2;

class DayScholar extends Student1 {
	
	public void commute() {
		System.out.println("I commute daily by train to study!!!!");
	}
	
	public void tifin() {
		System.out.println("I bring Tifin");
	}
	
	

}
