package com.day2;

public class ElectronicAppliance {
	
	public void switchOn() {
		System.out.println("Switching On!!!");
	}
	
	public void switchOff() {
		System.out.println("Switching Off!!!");
	}
	

}
