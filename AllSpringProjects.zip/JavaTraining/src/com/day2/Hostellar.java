package com.day2;

class Hostellar extends Student1 {

	public void hostel() {
		System.out.println("I live at Hostel");
	}
	
	public void mess() {
		System.out.println("I eat at Mess!!!");
	}
	
	public void noCommute() {
		System.out.println("I don't travel by train to study!!!");
	}
	
	
}
