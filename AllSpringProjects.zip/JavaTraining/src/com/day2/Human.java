package com.day2;

public class Human extends Primate{ //human is a primate  
	
	public void think() {
		System.out.println("I CAN THINK!");
	}
	
	public void talk() {
		System.out.println("I can Talk !!!!");
	}

}
