package com.day2;

public class Primate {
	public void jump() {
		System.out.println("jumps!!");
		
	}
	
	public void eat() {
		System.out.println("eating!!!");
	}
	
	public void walk() {
		System.out.println("walks with 2 legs and 2 hands");
	}

}
