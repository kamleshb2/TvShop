package com.day2;

public class Ques3 {

	private String username;
	private String password;
	
	Ques3(String name, String pass) {
		// TODO Auto-generated constructor stub
		username = name;
		password = pass;
		}

	
	public String getUsername() {
		return username;
	}

	public String getPassword() {
		return password;
	}
	
	

}
