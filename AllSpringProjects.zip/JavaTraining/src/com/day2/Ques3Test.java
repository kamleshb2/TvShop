package com.day2;

public class Ques3Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Ques3 q = new Ques3("Kamlesh", "abc123");
		System.out.println(q.getUsername());
		System.out.println(q.getPassword());

	}

}
