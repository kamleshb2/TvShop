package com.day2;

public class Radio extends ElectronicAppliance{
	
	public void prevFrequency() {
		System.out.println("Changing to previous frequency!");
	}
	
	public void nextFrequency() {
		System.out.println("Changing to next frequency!");
	}

}
