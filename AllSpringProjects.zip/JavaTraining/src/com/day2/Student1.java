package com.day2;

public class Student1 {
	
	public void study() {
		System.out.println("Student is Studying");
	}
	
	public void exam() {
		System.out.println("Student is giving exam");
	}
	
	public void result() {
		System.out.println("Result is out");
	}

}
