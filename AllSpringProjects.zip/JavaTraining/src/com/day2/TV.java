package com.day2;

public class TV extends ElectronicAppliance{
	
	public void prevChannel() {
		System.out.println("Changing channel to previous one!");
	}
	
	public void nextChannel() {
		System.out.println("Changing channel to next one!");
	}
	
	
}
