package com.day2;

public class TestAssignment {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Assignment a1 = new Assignment();
		Assignment a2 = new Assignment();
		
		System.out.println(Assignment.count);
		
	}

}
