package com.day2;

public class TestQues4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student1 st = new Student1();
		st.study();
		st.exam();
		st.result();
		
		DayScholar d1 = new DayScholar();
		d1.commute();
		d1.tifin();
		
		Hostellar h1 = new Hostellar();
		h1.hostel();
		h1.mess();
		h1.noCommute();                                                            
		
		}

}
