package com.day2;

class Assignment{
	
	static int count;
	
	Assignment(){
		count++;
		}
}
