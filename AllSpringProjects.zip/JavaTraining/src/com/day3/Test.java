package com.day3;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
				Admin a1 = new Admin();
				Manager m1 = new Manager();
				Security s1 = new Security();
				
				System.out.println(Employee.count); 
				

	}

}
