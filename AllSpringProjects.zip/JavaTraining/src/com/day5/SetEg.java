package com.day5;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

public class SetEg {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Set s = new LinkedHashSet();
		s.add(10);  
		s.add(100);
		s.add(10000);
		s.add(1780);
		
		System.out.println(s);
		

	}

}
