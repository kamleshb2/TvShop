package com.day6;

public class ExceptionDemo {
	
	public static void main(String[] args) {
		int a=0, b=90;
		
	}

}
