package com.day7;

class NegativeNumberException extends Exception{
	public NegativeNumberException() {
		
	}
	
	public NegativeNumberException(String msg) {
		super(msg);
	}
	
	
}

