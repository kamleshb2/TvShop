package com.day7;

public class PropertyClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

	}

}
