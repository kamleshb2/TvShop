package com.day8;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.DosFileAttributes;

public class IOeg1 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		final String FILE_NAME = "b.txt";
		//Files class
		//pATH cLASS
		String Home = System.getProperty("user.home");
//		Path p = Paths.get(Home + "/b.txt");      //converts string into path
//		Path f = Files.createFile(p);   //AccessDeniedException
//		System.out.println(" " + f + "created" );
//		

		
//		//to create folder
//		Path p = Paths.get(Home + "/directory1/directory2/directory3");  //throws exception
//		
//		//to create multiple directories
//		
//		Files.createDirectories(p);
//		Files.createDirectory(p);//for single directory
//		System.out.println("created");
		Path p1 = Paths.get(Home + "/directory1/directory2/directory3/b.txt"); 
		Files.createFile(p1);
//		System.out.println("" + Files.isDirectory(p)); //tells whether pointing towards directory or not
//		
//		System.out.println("" + Files.isReadable(p));  //whether readable
//		System.out.println("" + Files.isWritable(p));	//whether writable
		
		Files.delete(p1);
		
		
		
		
		
	}

}
