package com.day8;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

public class IOeg2 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		//To read and write files, go for FileReader, writer 
//		FileReader fn = new FileReader("Untitled 1");
//		BufferedReader br = new BufferedReader(fn);
//		String line = br.readLine();
//		System.out.println(line);
		
		FileWriter fw = new FileWriter("a.txt"); //will create file if not available 
		fw.write("welcome!!"); 
		fw.close();   //if resource is not closed, data won't be available
		
		
		
//		InputStreamReader isr = new InputStreamReader(System.in);
//		BufferedReader br = new BufferedReader(isr);
//		int ascii = 0;
//		while(((ascii=isr.read()) != -1)) {
//			System.out.println((char)ascii);
//		}
//		
//		String line = br.readLine();   //to read line, stores in a buffer
//		System.out.println(line);

	}

}
