package com.day8;
import java.io.*;
import java.util.*;

public class Ques1 {


	public static void main(String args[]) throws IOException {        
	    try {
	        File input = new File("a.txt");
	        File output = new File("b.txt");
	        Scanner sc = new Scanner(input);
	        FileWriter printer = new FileWriter(output);
	        while(sc.hasNextLine()) {
	            String s = sc.nextLine();
	            printer.write(s);
	        }
	    }
	    catch(FileNotFoundException e) {
	        System.err.println("File not found. Please scan in new file.");
	    }
	}
}
