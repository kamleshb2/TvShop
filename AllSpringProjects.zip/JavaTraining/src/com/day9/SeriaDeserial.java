package com.day9;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class SeriaDeserial {

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		// TODO Auto-generated method stub
		
//		Account acc = new Account(1001, "aaaa", 9000);
//		serialize(acc);
		Account myObj = deSerialize();
		System.out.println(myObj);
	}
	
	static void serialize(Account acc) throws IOException {
		//file to write and who can write into file
		if(acc instanceof Serializable) {
		FileOutputStream fout = new FileOutputStream("account1.dat");
		ObjectOutputStream objWriter = new ObjectOutputStream(fout);
		objWriter.writeObject(acc); //if account class not marked serializable, throws exception
		System.out.println("Data is written");
		}
		else {
			System.out.println("Can't write");
		}
	}
	
	static Account deSerialize() throws IOException, ClassNotFoundException {
		Account a = null;
		FileInputStream fis = new FileInputStream("Account1.dat");
		ObjectInputStream ois = new ObjectInputStream(fis);
		Object ob = ois.readObject();
		a = (Account)ob;
		return a;
	}

}
