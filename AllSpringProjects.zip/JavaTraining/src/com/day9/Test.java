package com.day9;

import java.util.HashMap;
import java.util.Scanner;

class demo
{
	public static void main(String[] args) {
	HashMap<String, String> map=new HashMap<String, String>();
	map.put("key1","Java");
	map.put("key2","Servlets");
	map.put("key3","JSP");
	map.put("key1","C#");

	System.out.println(map);

}
}
