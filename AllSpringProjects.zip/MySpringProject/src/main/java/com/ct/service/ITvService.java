package com.ct.service;

import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.web.servlet.ModelAndView;

import com.ct.model.Tv;

@Component
public interface ITvService {
	
	public ModelAndView predAdd(); 
	public void addTv(Tv t);
	public List<Tv> displayTv();
	public Tv retriveTv(int tId);

}
