package com.ct;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/myServ")
public class MyServ extends HttpServlet {
	int count=1;
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	//PrintWriter out=resp.getWriter();
	//resp.setHeader("refresh", "5");
	//resp.setContentLength(8);
	resp.setContentType("text/html");
//	resp.setIntHeader(name, value);
	//out.println("<h1>hello</h1> "+(++count));
	PrintWriter out=resp.getWriter();
	out.println("<html> <head><title>Mobile page</title></head>");
	out.println("<body>");
	String id=req.getParameter("id");
	String price=req.getParameter("price");
	
	out.println("id is "+id);
	out.println("price is "+price);
	out.println("</body>");
	out.println("</html>");
//	System.out.println(req.getHeader("Accept-Language").split("-")[0]);
	//out.println(req.getHeader("Accept-Language").split("-")[0].equals("en")?"translate":"---");
	
	
}

@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		super.doPost(req, resp);
	}

}
