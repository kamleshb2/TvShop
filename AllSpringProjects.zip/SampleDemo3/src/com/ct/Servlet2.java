package com.ct;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Servlet2
 */
@WebServlet("/myserv2")
public class Servlet2 extends HttpServlet {

	RequestDispatcher rd=null;
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	
		String finalData=req.getParameter("id")+" "+req.getParameter("name")+" "+req.getParameter("price");
		//		String rams[]=req.getParameterValues("ram")
		
		req.setAttribute("data", finalData);
		rd=req.getRequestDispatcher("vs");//gets the address of view servlet
		//req.setAttribute("data", finalData);
		rd.forward(req, resp);//dont call this twice

	}

}



