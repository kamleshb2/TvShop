package com.ct;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ViewServlet
 */
@WebServlet(name = "vs", urlPatterns = { "/vs" })
public class ViewServlet extends HttpServlet {
	PrintWriter out=null;
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		out=resp.getWriter();
		out.println("in post - vs");
		/*out.println(req.getParameter("id"));
		out.println(req.getParameter("name"));
		out.println(req.getParameter("price"));*/
		String h=(String)req.getAttribute("data");
		out.println(h);
	}
	
}