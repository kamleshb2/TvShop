package com.ct;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Servlet1
 */
@WebServlet("/Servlet1")
public class Servlet1 extends HttpServlet {
	RequestDispatcher rd = null;
	PrintWriter out = null;
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub

	}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		rd = req.getRequestDispatcher("/Servlet2");
		String id = req.getParameter("id");
		String name = req.getParameter("name");
		req.setAttribute("id", id );
		req.setAttribute("name", name );
		HttpSession session  = req.getSession(true);
		out = resp.getWriter();
		out.println("<a href = 'Servlet2'>Click for serv 2 </a> ");
		
		
		//rd.forward(req, resp);
	}

}
