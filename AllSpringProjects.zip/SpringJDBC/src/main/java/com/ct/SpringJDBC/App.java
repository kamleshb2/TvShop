package com.ct.SpringJDBC;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ct.custdao.Customer;
import com.ct.custdao.CustomerDao;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
       ApplicationContext context = null;
       
       AnnotationConfigApplicationContext ct;
       

       
    	AnnotationConfigApplicationContext ct=new ClassPathXmlApplicationContext("springconfig.xml");   
       CustomerDao cust = (CustomerDao) context.getBean("edao");
       int status=cust.saveCustomer(new Customer(102,"Amit",35000)); 
       System.out.println(status);
    	
    	
    }
}
