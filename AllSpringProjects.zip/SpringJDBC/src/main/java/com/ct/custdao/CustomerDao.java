package com.ct.custdao;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

public class CustomerDao {
	
	private JdbcTemplate jdbcTemplate;  
	  
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {  
	    this.jdbcTemplate = jdbcTemplate;  
	}  
	  
	public int saveCustomer(Customer c){  
	    String query="insert into customer(id, name, salary) values(?,?,?)";
	    return jdbcTemplate.update(query, new Object[] {(Integer)c.getId(), (String) c.getName(), (Integer)c.getSalary()} ,new BeanPropertyRowMapper<Customer>(Customer.class));  
	}

}
