package com.ct.controller;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


import com.ct.model.Tv;


@Controller
public class HomeController {
	
	@RequestMapping("/")
	public String getHomePage(Model m) {
		Tv t = new Tv();
		m.addAttribute("tv", t);
		return "home";
	}
	
	@RequestMapping(value="/store", method=RequestMethod.POST)
	public String addToDatabase( @Valid @ModelAttribute("tv") Tv t, BindingResult br, Model m ) {
		if(br.hasErrors()) {
			System.out.println(br);
			
		}
		
		else {
			System.out.println(br);
		}
		return "home";
	}
	
	

}
