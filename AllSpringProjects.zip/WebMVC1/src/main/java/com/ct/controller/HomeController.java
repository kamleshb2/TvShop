package com.ct.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ct.dao.TvDao;
import com.ct.model.Tv;


@RestController
public class HomeController {
	
	ApplicationContext ctx = null;
	@Autowired
	TvDao tv;
	
	@RequestMapping("/")
	public String getHomePage(Model m) {
		Tv t = new Tv();
		m.addAttribute("tv", t);
		return "home";
	}
	
	@RequestMapping(value="/store", method=RequestMethod.POST)
	public String addToDatabase(@Valid @ModelAttribute("tv") Tv t, BindingResult br, Model m ) {
		if(br.hasErrors()) {
			System.out.println(br);
			return "home";
		}
		
		else {
			int status = tv.saveTv(t);
			m.addAttribute("success", "data is successfully inserted");
			return "result";
		}
	}
	
	

}
