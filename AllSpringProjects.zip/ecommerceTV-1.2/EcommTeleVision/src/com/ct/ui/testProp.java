package com.ct.ui;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.UUID;

public class testProp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String id = UUID.randomUUID().toString();
		System.out.println(id);

	}

}
