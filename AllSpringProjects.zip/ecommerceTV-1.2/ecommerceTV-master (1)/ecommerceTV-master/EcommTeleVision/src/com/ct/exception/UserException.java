package com.ct.exception;

public class UserException extends Exception {

	public UserException() {
		// TODO Auto-generated constructor stub
	}
	public UserException(String s) {
		super(s);
		// TODO Auto-generated constructor stub
	}
}
