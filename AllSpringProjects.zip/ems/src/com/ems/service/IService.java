package com.ems.service;

public class IService {

}
