package ems;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class PrpoDemo {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		//FileInputStream fis=new FileInputStream("connection_prop.properties"); 
        Properties prop=new Properties (); 
        Properties p=new Properties();
		p=System.getProperties();
		System.out.println(p);
       // prop.load(fis); 
        
        System.out.println(prop);
        System.out.println(p.getProperty("os.name"));
        p.put("key1", "value1");
        System.out.println(p.getProperty("key1"));

	}

}
