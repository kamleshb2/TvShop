package ems;

public class Ui {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PrpoDemo d = null;
		Ui i = new Ui();
		d = i.testCode();

	}
	
	public PrpoDemo testCode() {
		PrpoDemo p = null;
		try {
		int i = 2/0;
		}
		catch(ArithmeticException e) {
			
		}
		return p;
	}

}
