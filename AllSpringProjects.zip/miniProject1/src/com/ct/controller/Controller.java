package com.ct.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Controller
 */



@WebServlet("*.do")
public class Controller extends HttpServlet {
	

	
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String path = req.getServletPath();
		RequestDispatcher rd =RequestDispatcher req.getre
		resp.setHeader("Refresh", "5; URL=https://www.google.com/");
		switch(path)
		{
		case "/add.do":
			
			add();
			
			break;
		
		case "/delete.do":
			delete();
			
			break;
			
		case "/update.do":
			update();
			
			break;
			
		case "/id.do":
			searchById();
			
			break;
			
		case "/retrieve.do":
			retrieveById();
			
			break;
		
		}
	}

	private void retrieveById() {
		// TODO Auto-generated method stub
		System.out.println("In retrive by id method");
	}

	private void searchById() {
		// TODO Auto-generated method stub
		System.out.println("In searchbyId method");
	}

	private void update() {
		// TODO Auto-generated method stub
		System.out.println("In update method");
	}

	private void delete() {
		// TODO Auto-generated method stub
		System.out.println("In delete method");
	}

	private void add() {
		// TODO Auto-generated method stub
		System.out.println("In add method");
		
	}
	
}
